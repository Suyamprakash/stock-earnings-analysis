package main.java.boeing.codegen;


import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class Test {

	static Connection connection = null;
	static DatabaseMetaData metadata = null;

	public static void main(String[] args) {
		Connection conn = null;
		try {
			String dbURL =  "jdbc:sqlserver://SQL-SWCS-18-1I\\IIDEV05;databaseName=d_SandboxD;integratedSecurity=true";

			/*
			String dbURL = "jdbc:sqlserver://sql-ewhcld-1000.sw.nos.boeing.com;databaseName=exreldb__54zdii2hrut";
			String user = "tenant-fed15e45-8435-4be7-a642-c52bd10c8f32";
			String pass = "4aff6824-54ab-44d5-8762-d9f96fd171b4";
			*/
			conn = DriverManager.getConnection(dbURL);
			if (conn != null) {
				metadata = (DatabaseMetaData) conn.getMetaData();
				System.out.println("Driver name: " + metadata.getDriverName());
				System.out.println("Driver version: " + metadata.getDriverVersion());
				System.out.println("Product name: " + metadata.getDatabaseProductName());
				System.out.println("Product version: " + metadata.getDatabaseProductVersion());

				getColumnsMetadata(getTablesMetadata());
			}

		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			try {
				if (conn != null && !conn.isClosed()) {
					conn.close();
				}
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
	}

	public static ArrayList<String> getTablesMetadata() throws SQLException {
		String table[] = { "TABLE" };
		ResultSet rs = null;
		ArrayList<String> tables = null;
		// receive the Type of the object in a String array.
		rs = metadata.getTables(null, null, null, table);
		tables = new ArrayList<String>();
		while (rs.next()) {
			tables.add(rs.getString("TABLE_NAME"));
		}
		return tables;
	}

	public static void getColumnsMetadata(ArrayList<String> tables)
			throws SQLException {
		ResultSet rs = null;
		// Print the columns properties of the actual table
		for (String actualTable : tables) {
			rs = metadata.getColumns(null, null, actualTable, null);
			System.out.println(actualTable.toUpperCase());
			while (rs.next()) {
				System.out.println(rs.getString("COLUMN_NAME") + " "
						+ rs.getString("TYPE_NAME") + " "
						+ rs.getString("COLUMN_SIZE"));
			}
			System.out.println("\n");
		}
	}
}